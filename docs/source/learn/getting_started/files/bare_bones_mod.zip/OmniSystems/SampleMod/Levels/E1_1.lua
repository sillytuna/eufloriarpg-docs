--
-- Level script
--

function OnInitialiseLevel()
	ParseConfig([[
		Level.seed										436743264

		Level.musicGroupStartFirstTrack					Strength

		Level.Diggers.maxDiggers						0

		Level.pressureLevel								5

		Level.levelColour1								20,20,70
		Level.doorColour								50,60,55

		GameDefs.ColonyManager.alpha					0.4

		SelectMapEffect DistanceField
			Set mode					Border
			Set bgColour				220,200,180
			Set fgColour				60,50,40
			Set dfColour				230,150,150
			Set borderColour			90,120,90
			Set borderThickness			.01
			Set borderSoftness			.07
			Set colonyThickness			0.45
			Set bgRepeat				3.5
			Set fgRepeat				10
			Set parallaxSpeed			.3
			Set fgDisplacementTime		0
			Set dfBias					90
			Set dfAnimatedBias			64
			Set dfInvert				false
			Set heartbeatTime			2
			Set heartbeatFadeUp			0.1
			Set heartbeatFadeUpAcc		10
			Set heartbeatFadeDown		0.05
			Set bgTexture				Cloud_2
			Set fgTexture				Shards_2
			Set bgOffset				0,0
			Set fgOffset				0,0

			Set bg2Enabled				true
			Set bg2Texture				Middle_Clouds
			Set bg2Repeat				3
			Set bg2Colour				180,170,160
			Set parallax2Speed			0.25
			Set bg2ScrollSpeed			0.004,-0.002

		SetPath Level.FrontLayers
			Set fgEnabled				true
			Set fgTexture				Middle_Clouds
			Set fgColour   				200,200,200
			Set fgRepeat				3.5
			Set fgParallax				-0.1
			Set fgOffset				0,0
			Set fgScrollSpeed			0.01,-0.005
			Set fgAlpha					0.7

		SetPath Level.FogOfWar
			Set colour					60,60,60

	]])
end


function OnPostGenerateLevelMap()
	EditMap('Position:256,256 Size:512,512 Rectangle')
	EditMap('Position:256,256 Size:512,512 Fill Rectangle Texture:E1_1')
end


function OnPopulateLevel()
	-- Vortices
	SpawnVortex('Type:DownVortexYellow Name:Vortex1 Position:466,347.6 Locked:True Message:"Locked in this alpha"')
	SpawnVortex('Type:DownVortexYellow Name:Vortex2 Position:392,151 Locked:True Message:"Locked in this alpha"')
	SpawnVortex('Type:UpVortexGreen Name:Vortex3 Position:191,164')

	-- SpawnVortex('Type:UpVortex Name:Vortex4 Position:369.5,326')

	-- Tunnel Vortices
	-- SpawnVortex('Type:TunnelVortexYellow Name:Vortex5 Position:230,136 IsOneShot:false DataCanColor:Yellow')-- tunnel to E3_3

	-- Doors
	SpawnDoor('Type:Default Name:ArtifactDoor_1 AnchorA:278,303 AnchorB:288,303 State:Locked')
	SpawnDoor('Type:Default Name:ArtifactDoor_2 AnchorA:350,334 AnchorB:350,345 State:Locked')
	--SpawnDoor('Type:Default Name:TrapDoor_1 AnchorA:448,262 AnchorB:480,256 State:Open')
	--SpawnDoor('Type:Default Name:TrapDoor_2 AnchorA:440,190 AnchorB:447,203 AnchorB:456,183 State:Open')
	--SpawnDoor('Type:Default Name:TrapDoor_3 AnchorA:416,191 AnchorB:397,186 State:Open')
	--SpawnDoor('Type:Default Name:TrapDoor_4 AnchorA:468,92 AnchorB:449,87 State:Open')
	--SpawnDoor('Type:Default Name:TrapDoor_5 AnchorA:406,94 AnchorB:422,88 State:Open')

	-- Player
	SpawnColony('Name:PlayerFriends Team:Player Size:85,50 Attributes:0.4,0.3,0.2 MaxEntitiesToSpawn:ScaredSeedling,16 Position:317,331')
		SpawnFlora('Type:EnergyTerraformTree Colony:PlayerFriends Angle:200 Position:332,346 Dormant:-1')
		SpawnFlora('Type:ScaredDysonTree Colony:PlayerFriends Dormant:-1')
		SpawnFlora('Type:ScaredDysonTree Colony:PlayerFriends Dormant:-1')
		SpawnFlora('Type:ScaredDysonTree Colony:PlayerFriends Dormant:-1')

	-- SpawnColony Name:PlayerFriends_2 Team:Player Size:50,60 Attributes:0.4,0.3,0.3 MaxEntitiesToSpawn:ScaredSeedling,4 Position:207,161
		-- SpawnFlora('Type:DysonHearts Colony:PlayerFriends_2 Dormant:-1')
		-- SpawnFlora('Type:ArtifactTree Colony:PlayerFriends_2  Dormant:-1')

	SpawnColony('Name:PlayerFriends_3 Team:Player Size:50,60 Attributes:0.1,0.4,0.1 MaxEntitiesToSpawn:ScaredSeedling,15 Position:488,149')
		SpawnFlora('Type:DysonHearts Colony:PlayerFriends_3 Position:486,136 Dormant:-1')
		SpawnFlora('Type:ScaredDysonTree Colony:PlayerFriends_3 Position:467,144 Dormant:-1')
		SpawnFlora('Type:IceCoralTree Colony:PlayerFriends_3 Position:504,161 Dormant:-1')

	SpawnColony('Name:PlayerFriends_4 Team:Player Size:50,60 Attributes:0.4,0.2,0.2 MaxEntitiesToSpawn:ScaredSeedling,6 Position:333,186')
		SpawnFlora('Type:IceCoralTree Colony:PlayerFriends_4 Position:347,199 Dormant:-1')
		--SpawnFlora('Type:DysonReed Colony:PlayerFriends_4 Dormant:-1')
		SpawnFlora('Type:ArtifactTree Colony:PlayerFriends_4 Position:330,184 Dormant:-1')
		--SpawnFlora('Type:EnergyTerraformTree Colony:PlayerFriends_4 Dormant:-1')

	SpawnColony('Name:PlayerFriends_5 Team:Player Size:60,60 Attributes:0.1,0.4,0.1 SpawnRateMultiplier:2 MaxEntitiesToSpawn:Seedling,15 Position:230,223')
		SpawnFlora('Type:IceCoralTree Colony:PlayerFriends_5 LeafType:Seedling Level:4')
		SpawnFlora('Type:IceCoralTree Colony:PlayerFriends_5 LeafType:Seedling Level:3')
		SpawnFlora('Type:DysonGrass Colony:PlayerFriends_5 Dormant:-1')
		SpawnFlora('Type:DysonGrass Colony:PlayerFriends_5 Dormant:-1')
		SpawnFlora('Type:DysonGrass Colony:PlayerFriends_5 Level:4')
		SpawnFlora('Type:DysonGrass Colony:PlayerFriends_5 Dormant:-1')
		SpawnEntity('Type:Seedling Count:10 Colony:PlayerFriends_5')


	-- Enemies
	SpawnColony('Name:Energy_1 Team:Team5 Size:57,60 Attributes:0.3,0.3,0.2 MaxEntitiesToSpawn:StrongSeedling,6 SpawnRateMultiplier:3 Position:294,274')
		SpawnFlora('Type:IceCoralTree Colony:Energy_1 LeafType:StrongSeedling Level:3 Position:302,285')
		SpawnFlora('Type:IceCoralTree Colony:Energy_1 LeafType:StrongSeedling Level:3 Position:282,264')
		SpawnFlora('Type:IceCoralTree Colony:Energy_1 LeafType:StrongSeedling Level:3 Position:274,295')
		--SpawnFlora('Type:WildTree Colony:Energy_1 LeafType:StrongSeedling Level:3 Position:318,264')
		SpawnEntity('Type:StrongSeedling Count:5 Colony:Energy_1 Position:295,251')
		SpawnEntity('Type:StrongSeedling Count:5 Colony:Energy_1 Position:295,251')
		--SpawnPlayerFlora('Type:LockTreeRed Colony:Energy_1 Link:ArtifactDoor_1 Position:310,267')

	SpawnColony('Name:Energy_3 Team:Grey Size:60,50 Attributes:0.2,0.2,0.2 MaxEntitiesToSpawn:Seedling,3 Position:435,88')
		SpawnFlora('Type:WildTree Colony:Energy_3 LeafType:GuardSeedling Level:1 MaxEntitiesToSpawn:1')
		SpawnFlora('Type:WildTree Colony:Energy_3 LeafType:GuardSeedling Level:1 MaxEntitiesToSpawn:1')
		SpawnFlora('Type:AngularTree Colony:Energy_3 LeafType:Seedling Level:4')
		SpawnEntity('Type:GuardSeedling Count:3 Colony:Energy_3')
		--SpawnPickup('Type:BombPickup Colony:Energy_3 Position:439.762,74.7299')

	SpawnColony('Name:Energy_4 Team:Team9 Size:88,60 Attributes:0.5,0.5,0.1 Position:473,302')
		SpawnFlora('Type:FastDefenseHexAngularTree Colony:Energy_4 Dormant:-1')
		SpawnFlora('Type:FastDefenseHexAngularTree Colony:Energy_4 Dormant:-1')
		SpawnFlora('Type:FastDefenseHexAngularTree Colony:Energy_4 Dormant:-1')

	-- Pacifists
	SpawnColony('Name:Foragers1 Team:Team9 Size:50,50 Attributes:0.5,0.4,0.1 Position:383.228,27.7872')
		SpawnFlora('Type:Bracken LeafType:Missile Level:4 Colony:Foragers1 Position:372,42')
		SpawnPlayerFlora('Type:DysonFruit Colony:Foragers1')

	SpawnColony('Name:Foragers2 Team:Team9 Size:55,50 Attributes:0.4,0.2,0.2 Position:224,287')
		SpawnFlora('Type:Bracken Fruit:True LeafType:Missile Colony:Foragers2 Position:236,300 Level:5')
		SpawnPlayerFlora('Type:DysonReed Colony:Foragers2')
		SpawnPlayerFlora('Type:DysonFruit Colony:Foragers2')

	SpawnColony('Name:Foragers3 Team:Team9 Size:60,60 Attributes:0.3,0.6,0.3 Position:394,301')
		SpawnFlora('Type:Bracken LeafType:Missile Colony:Foragers3 Level:4 Position:409,309')
		SpawnFlora('Type:Bracken LeafType:Missile Colony:Foragers3 Level:4 Position:387,292')
		SpawnPlayerFlora('Type:DysonFruit Colony:Foragers3')
		--SpawnPlayerFlora('Type:LockTreeRed Colony:Foragers3 Link:ArtifactDoor_2')

	-- Greys
	SpawnColony('Name:Greys1 Team:Grey Size:60,70 Attributes:0.3,0.4,0.2 MaxEntitiesToSpawn:Seedling,0 Position:486,19')
		SpawnFlora('Type:AngularTree Colony:Greys1 LeafType:Seedling Level:1')
		SpawnFlora('Type:AngularTree Colony:Greys1 LeafType:Seedling Level:3')
		SpawnFlora('Type:WildTree Colony:Greys1 LeafType:GuardSeedling Level:3')
		SpawnEntity('Type:GuardSeedling Count:3 Colony:Greys1')
		-- SpawnPlayerFlora('Type:ArtifactTree Colony:Greys1')


	SpawnColony('Name:Greys2 Team:Grey Size:81,56 Attributes:0.4,0.5,0.2 MaxEntitiesToSpawn:Seedling,3 Position:491,208')
		SpawnFlora('Type:AngularTree Colony:Greys2 LeafType:Seedling Level:4  Angle:270 Position:503,222')
		SpawnFlora('Type:AngularTree Colony:Greys2 LeafType:Seedling Level:2 Angle:300 Position:493,213')
		SpawnFlora('Type:WildTree Colony:Greys2 LeafType:GuardSeedling Level:4')
		SpawnPlayerFlora('Type:DysonReed Colony:Greys2')
		SpawnPlayerFlora('Type:DysonReed Colony:Greys2')

	SpawnColony('Name:Greys3 Team:Grey Size:50,60 Attributes:0.2,0.3,0.2 MaxEntitiesToSpawn:Seedling,0 MaxEntitiesToSpawn:GuardSeedling,1 Position:374,236')
		SpawnFlora('Type:WildTree Colony:Greys3 LeafType:GuardSeedling Level:4 Position:382,234')
		SpawnFlora('Type:AngularTree Colony:Greys3 LeafType:Seedling Level:3 Position:358,238')
		SpawnFlora('Type:AngularTree Colony:Greys3 LeafType:Seedling Level:3')	--Position:310,200
		SpawnEntity('Type:GuardSeedling Count:3 Colony:Greys3')

	SpawnEntity('Type:Mine Count:3 Team:Grey Position:444,153 Attributes:0.2,0.7,0.05')
	SpawnEntity('Type:Mine Count:3 Team:Grey Position:406,171 Attributes:0.2,0.7,0.05')

	SpawnFlora('Type:StrengthTerraformTree Team:Player Position:175,191')
	SpawnFlora('Type:EnergyTerraformTree Team:Player Position:427,213')
	SpawnFlora('Type:EnergyTerraformTree Team:Player Position:417,213')
	SpawnFlora('Type:EnergyTerraformTree Team:Player Position:437,213')
	SpawnFlora('Type:SpeedTerraformTree Team:Player Position:492,256')

	-- TODO: Need some colonies without seedlings but messed up trees
	--SpawnFlora('Type:DenseBush Attributes:0.3,0.3,0.3 Position:266,168 Level:4')

	-- DataCans
	SpawnDataCan('ID:E1_1A Position:246,151')

	-- Pickups
	--SpawnPickup('Type:HealthPickup Position:283.4652,325.2726')
	SpawnPickup('Type:HealthPickup Position:200,324')
	SpawnPickup('Type:ShockwavePickup Position:335,23')
	SpawnPickup('Type:HealthPickup Position:449,296') --InvisibilityPickup

	SpawnArtifact('Type:AvoidArtifact Position:321,320')

	-- SpawnSeed('Type:GuardSeed Position:344,76')

	-- Grass
	SpawnGrassArea('Type:CyanMediumClump Attributes:0.35,0.2,0.7 Position:256,256 Size:512,512 Amount:15')
	SpawnGrassArea('Type:BlackFern Attributes:0.35,0.2,0.7 Position:256,256 Size:512,512 Amount:45')

	if Level.hasConqueredAllColonies then
		SpawnVortex('Type:HubVortex Name:VortexSpecial Position:431,39')
	end
end


function OnPostPopulateLevel()
	local node

	-- Reward the player with energy when they've discovered all the colonies
	node = MissionDef:AddMission("PlayerFriends3Mission", "PlayerFriends_3", "You can help us!\\r\\nIf you rescue all the lost colonies in this sector, we will reward you.\\r\\nBut beware of traps!")
	node = node:IfCustomTrigger(function() return App.colonyManager.hasDiscoveredAllColonies end):AddNode("Thank you friend. Here is your reward.")
	node = node:IfMessageFinished():AddNode("All our Colonies have been revived!\\r\\nPraise the growers!")
	node = node:SetOnEnter(function() SpawnEnergy("Colony:PlayerFriends_3 Radius:20 Amount:250 Particles:20") end)
	node:StartMission()

	-- Wait for Energy_1 or Foragers3 to be colonised
	local node = MissionDef:AddMission("PlayerFriends4Mission", "PlayerFriends_4", "The gatekeepers up above guard an artifact.\\r\\nThey must be defeated.")
	node:IfColonyConquered("Energy_1"):AddDestroyNode()
	node:IfColonyConquered("Foragers3"):AddDestroyNode()
	node:StartMission()

	-- Send the player on a mission to Foragers2 and reward them on their return
	node = MissionDef:AddMission("PlayerFriends5Mission", "PlayerFriends_5", "Please help us!\\r\\nThe enemy missile plant above us has pinned us down.")
	node = node:IfColonyConquered("Foragers2"):AddNode("Well, you sure took care of that plant. Here is something that may help you.")
	node = node:IfMessageFinished():AddNode("It has the power to temporarily freeze any nearby enemies.")
	node = node:SetOnEnter(function() SpawnPickup('Type:StasisPickup Position:200,223') end)
	node = node:DestroyAfterMessage()
	node:StartMission()

	-- Trap the player in Energy_4 until they destroy it
	--node = MissionDef:AddMission("Trapdoor", "Energy_4")
	--node = node:IfInRange():AddNamedNode("Trap")
	--node = node:SetOnEnter(function() LockDoor("TrapDoor_1") end)

	-- If entity dies, reset the trap
	--node:IfEntityDied("PlayerShip"):AddNode():SetOnEnter(function() UnlockDoor("TrapDoor_1") end):IfInRange():Goto("Trap")
	-- If the game was reloaded, reset the trap
	--node:IfReloaded():AddNode():SetOnEnter(function() UnlockDoor("TrapDoor_1") end):IfInRange():Goto("Trap")

	--node = node:IfColonyConquered("Energy_4"):AddNode()
	--node = node:SetOnEnter(function() UnlockDoor("TrapDoor_1") end)
	--node = node:Continue():AddDestroyNode()
	--node:StartMission()

	-- Always start with the trap door unlocked as a fail safe
	--UnlockDoor("TrapDoor_1")
end


function OnColonyConquered(colony, team, lastTeam)
	if not team.isPlayer then return end

	if (colony.name == "Foragers3" or colony.name == "Energy_1") then
		-- Unlock both doors when either colony is conquered
		UnlockDoor("ArtifactDoor_1")
		UnlockDoor("ArtifactDoor_2")
	end

	if Level.hasConqueredAllColonies then
		SpawnVortex('Type:HubVortex Name:VortexSpecial Position:431,39')
	    App.hudManager.ActivateItemDescription("Mysterious Vortex", "A Vortex has appeared", "HubVortex", 1.2)
	end
end



